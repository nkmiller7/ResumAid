function computerScience(){
    location.href = "computer.html"
}

function cyber(){
    location.href = "cyber.html"
}

function computerEngr(){
    location.href = "engr.html"
}

function biology(){
    location.href = "biology.html"
}

function buisness(){
    location.href = "buisness.html"
}

function marketing(){
    location.href = "marketing.html"
}

function education(){
    location.href = "education.html"
}

function showExample(i) {
    var txt = document.getElementsByClassName("exDescription");
    if (txt[i].style.display != 'block') {
        txt[i].style.display = 'block';
    } else {
        txt[i].style.display = 'none';
    }
}

